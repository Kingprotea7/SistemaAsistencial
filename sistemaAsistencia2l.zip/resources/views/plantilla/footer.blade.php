<footer class="footer mt-auto py-3 bg-dark">
    @yield('footer')
    <div class="container text-center">
        <span class="text-muted">© 2023 Lucia Quispe Nina ||</span>
    </div>

    
</footer>

