<?php $__env->startSection('content'); ?>
<div class="container mt-5 saber">
    <h2 class="text-center mb-4 h1">Reporte asistencial</h2>

    <?php if($reportesDiarios->count() > 0): ?>
        <table class="table table-bordered table-striped table-dark">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Tipo de Reporte</th>
                    <th>Tipo de Asistencia</th>
                    <th>Día</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reportesDiarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reporteDiario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($reporteDiario->tipo_asistencia): ?>
                    <tr>
                        <td><?php echo e($reporteDiario->id); ?></td>
                        <td><?php echo e($reporteDiario->alumno->nombreCompleto()); ?></td>
                        <td><?php echo e($reporteDiario->alumno->apellido()); ?></td>
                        <td><?php echo e($reporteDiario->alumno->lastname2()); ?></td>
                        <td><?php echo e($reporteDiario->tipo_reporte); ?></td>
                        <td><?php echo e($reporteDiario->tipo_asistencia); ?></td>
                        <td><?php echo e($reporteDiario->dia); ?></td>
                        <td>
                            <!-- Puedes agregar botones de acciones aquí según tus necesidades -->
                        </td>
                    </tr>
                <?php else: ?>
                    <tr class="bg-danger table-danger text-white">
                        <td class="h5 text-center bg-danger  text-dark" colspan="8">
                            <?php echo e($reporteDiario->alumno->nombreCompleto()); ?>,
                            <?php echo e($reporteDiario->alumno->apellido()); ?>,
                            <?php echo e($reporteDiario->alumno->lastname2()); ?> <br>
                            Posee registros corruptos, se recomienda rehacer el reporte del salón.
                        </td>
                    </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-center bg-dark text-white">No hay reportes diarios disponibles.</p>
    <?php endif; ?>

    <div class=" bg-dark align-content-center text-center my-3">
      <p class="h3 text-white">  Acciones a realizar:</p>
      <form id="exportPdfForm" action="<?php echo e(route('reportetriple')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="btn btn-danger mx-4 my-2" >EXPORTAR PDF</div>
    </form>
        <div class="btn btn-success mx-4">EXPORTAR EXCEL</div>
        <div class="btn btn-info ">ENVIAR REPORTE</div>
    </div>
</div>

<style>

.saber{
    margin-bottom: 100px
}
@media (max-width: 768px) {
        .saber {
            margin-bottom: 150px/* Ajusta este valor para pantallas más pequeñas */


        }
    }
</style>
<script>
    function exportPdf() {
        document.getElementById('exportPdfForm').submit();
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/reporte/diario.blade.php ENDPATH**/ ?>