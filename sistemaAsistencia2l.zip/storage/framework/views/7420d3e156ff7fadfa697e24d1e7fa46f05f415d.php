<?php $__env->startSection('estilos'); ?>
    <!-- Incluye los estilos de Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="text-center"> <!-- Agregado el contenedor con la clase text-center para centrar -->
        <!-- Campo de entrada para la fecha -->
        <input type="text" id="calendario">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Inicializa Flatpickr sin el icono y mostrando automáticamente el calendario al hacer clic -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr("#calendario", {
            // Opciones de configuración...
            allowInput: true,
            clickOpens: true,
            dateFormat: "d-m-y"  // Puedes ajustar el formato de fecha según tus preferencias
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/reporte/reportemensual.blade.php ENDPATH**/ ?>