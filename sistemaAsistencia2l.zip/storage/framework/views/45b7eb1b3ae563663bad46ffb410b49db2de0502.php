<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    
    <?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Listado de Alumnos</h2>

        <?php if($alumnos !== null && count($alumnos) > 0): ?>
        <table class="table table-striped table-bordered table-hover text-center">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Num. de Padre</th>
                    <th>Nivel</th>
                    <th>Grado</th>
                    <th>Sección</th>
                    <th class="text-center bg-info text-red">Identificador</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($alumno->nombre); ?></td>
                    <td><?php echo e($alumno->apellido_paterno); ?></td>
                    <td><?php echo e($alumno->apellido_materno); ?></td>
                    <td><?php echo e($alumno->num_padre); ?></td>
                    <td><?php echo e($alumno->nivel); ?></td>
                    <td><?php echo e($alumno->grado); ?></td>
                    <td><?php echo e($alumno->seccion); ?></td>
                    <td class="text-center bg-info text-white"><?php echo e($alumno->numero_aleatorio); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
        <p>No se encontraron resultados.</p>
        <?php endif; ?>
    </div>

    <?php $__env->stopSection(); ?>

</body>
</html>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/dashboard/Salones/iteracionesPrimaria/listado/listado.blade.php ENDPATH**/ ?>