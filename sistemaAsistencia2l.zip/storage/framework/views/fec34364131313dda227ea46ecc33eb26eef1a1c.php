<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <form id="searchForm" action="<?php echo e(route('buscar-alumnos')); ?>" method="GET">
            <div class="input-group mb-3">
                <input type="text" class="form-control" name="query" placeholder="Buscar alumnos...">
                <div class="input-group-append">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        </form>

        <div class="col-md-4">
            <div class="card">
                <img src="<?php echo e(asset('ruta_a_tu_imagen1.jpg')); ?>" class="card-img-top" alt="Imagen 1">
                <div class="card-body text-center">
                    <h5 class="card-title">Asistencia por nivel</h5>
                    <a href="<?php echo e(route('Salones.listar')); ?>" class="btn btn-primary">Primaria</a>
                    <a href="<?php echo e(route('Salones.listarS')); ?>" class="btn btn-success">Secundaria</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="<?php echo e(asset('ruta_a_tu_imagen2.jpg')); ?>" class="card-img-top" alt="Imagen 2">
                <div class="card-body text-center">
                    <h5 class="card-title">Asignar Alumno nuevo</h5>
                    <a href="<?php echo e(route('Alumnado.create')); ?>" class="btn btn-primary text-center">Crear</a>
                </div>
            </div>
        </div>
    </div>

    <hr> <!-- Agregar línea horizontal como separador -->

    <?php if(isset($alumnos) && count($alumnos) > 0): ?>
        <h3 class="mt-4 text-primary">Resultados de la búsqueda</h3>
        <table class="table mt-2">
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="resultado-item">
                        <td><?php echo e($alumno->nombre); ?></td>
                        <td><?php echo e($alumno->apellido_paterno); ?></td>
                        <td><?php echo e($alumno->apellido_materno); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="mt-4">No se encontraron resultados.</p>
    <?php endif; ?>

    <?php if($errors->has('bien')): ?>
        <div class="alert alert-success">
            <?php echo e($errors->first('bien')); ?>

        </div>
    <?php elseif($errors->has('mal')): ?>
        <div class="alert alert-danger">
            <?php echo e($errors->first('mal')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/dashboard/Alumnado/Alumnado.blade.php ENDPATH**/ ?>