<footer class="footer mt-auto py-3 bg-dark">
    <?php echo $__env->yieldContent('footer'); ?>
    <div class="container text-center">
        <span class="text-muted">© 2023 Lucia Quispe Nina ||</span>
    </div>

    
</footer>

<?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/plantilla/footer.blade.php ENDPATH**/ ?>