<?php

use Illuminate\Database\Seeder;

class evenSeeder extends Seeder
{
public function run(){
    $events="";
}
}
