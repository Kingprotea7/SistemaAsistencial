<?php $__env->startSection('content'); ?>

<div class="dashboard">
    <div class="container mt-5">
        <!-- Tarjetas en horizontal, 4 por fila, centradas -->
        <div class="row justify-content-center ">
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('Alumnado.index')); ?>">
                        <img src="<?php echo e(asset('images/Alumnado (1).jpg')); ?>" class="card-img-top" alt="Imagen 1">

                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Alumnado</h5>
                            <p class="text-white text-decoration-none">Gestione la información de los alumnos registrados. </p>
                        </div>

                    </a>
                </div>
            </div>


            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('Salones.index')); ?>">
                        <img src="<?php echo e(asset('images/Salones (1).jpg')); ?>" class="card-img-top" alt="Imagen 1">

                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Salones</h5>
                            <p class="text-white text-decoration-none">Cree,edite y visualize información de los salones.</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('RegistrarAsistencia')); ?>">
                        <img src="<?php echo e(asset('images/Asistencia.jpg')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Asistencia</h5>
                            <p class="text-white text-decoration-none">Registre las asistencias de los alumnos mediante grado y sección.</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('reportes')); ?>">
                        <img src="<?php echo e(asset('images/reportes1.jpg')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Reportes</h5>
                            <p class="text-white text-decoration-none">Visualize,descargue y envíe reportes institucionales. </p>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Repite estas tarjetas para las otras 3 tarjetas en horizontal -->
        </div>
    </div>

    <div class="container mt-5">
        <!-- Tarjetas abajo, 4 por fila, centradas -->
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('mostrarusuarios')); ?>">
                        <img src="<?php echo e(asset('images/usuarios12.png')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Usuarios</h5>
                            <p class="text-white text-decoration-none">Visualize los usuarios registrados y su ultima conexión.</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('Alumnado.index')); ?>">
                        <img src="<?php echo e(asset('images/estad.png')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Historial</h5>
                            <p class="text-white text-decoration-none">Gestione las acciones de los usuarios del sistema.76</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('Alumnado.index')); ?>">
                        <img src="<?php echo e(asset('images/estadisticas.png')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Estadisticas</h5>
                            <p class="text-white text-decoration-none">Visualize las estadísticas mas resaltantes del plantel.</p>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card mb-4">
                    <a href="<?php echo e(route('Alumnado.index')); ?>">
                        <img src="<?php echo e(asset('images/soporte-tecnico.png')); ?>" class="card-img-top" alt="Imagen 1">
                        <div class="card-body text-center bg-dark">
                            <h5 class="h3 text-white text-decoration-none">Soporte técnico</h5>
                            <p class="text-white text-decoration-none">Tiene problemas,no dude en preguntar al soporte.</p>
                        </div>
                    </a>
                </div>
            </div>
            <!-- Repite estas tarjetas para las otras 3 tarjetas abajo -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\niko_\OneDrive\Escritorio\sistemaAsistencial\resources\views/dashboard/dashboard.blade.php ENDPATH**/ ?>