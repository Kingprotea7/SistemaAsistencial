<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center mb-4">Registrar Asistencia</h2>
    <form action="<?php echo e(route('mostrarAlumnosParaAsistencia')); ?>" method="GET">
        <div class="mb-3">
            <label for="nivel" class="form-label">Nivel Educativo</label>
            <select class="form-select" id="nivel" name="nivel" required>
                <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($nivel); ?>"><?php echo e($nivel); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="grade" class="form-label">Grado</label>
            <select class="form-select" id="grade" name="grade" required>
                <option value="">Seleccione un grado</option>
                <?php $__currentLoopData = $grados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($grado); ?>"><?php echo e($grado); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="seccion" class="form-label">Sección</label>
            <select class="form-select" id="seccion" name="seccion" required>
                <option value="">Seleccione una sección</option>
                <?php $__currentLoopData = $secciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($seccion); ?>"><?php echo e($seccion); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Mostrar Alumnos</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/dashboard/Asistencia/listadoSG.blade.php ENDPATH**/ ?>