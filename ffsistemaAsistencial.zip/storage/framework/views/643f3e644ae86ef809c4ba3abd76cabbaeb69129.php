<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="custom-card border rounded shadow">
                <div class="custom-card-header bg-primary text-white">
                    <h1 class="card-title text-center">Editar Salón</h1>
                </div>
                <form action="<?php echo e(route('Salones.store1', ['id' => $salon->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <!-- Agregar un campo oculto con el id del salón -->
                    <input type="hidden" name="salon_id" value="<?php echo e($salon->id); ?>">

                    <div class="mb-3">
                        <label for="docente_id" class="form-label">Tutor</label>
                        <select class="form-select" id="docente_id" name="docente_id" required>
                            <option value="" selected disabled>Seleccione un nuevo tutor</option>
                            <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($docente->id); ?>"><?php echo e($docente->name); ?> <?php echo e($docente->lastname); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <button type="submit" class="btn btn-primary">Editar Salón</button>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const nivelSelect = document.getElementById('nivel');
    const gradeSelect = document.getElementById('grade');
    nivelSelect.addEventListener('change', function () {
        if (nivelSelect.value === 'secundaria') {
            gradeSelect.querySelector('option[value="6"]').style.display = 'none';
        } else {
            gradeSelect.querySelector('option[value="6"]').style.display = 'block';
        }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/dashboard/Salones/editar.blade.php ENDPATH**/ ?>