<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center mb-4">Salones de Nivel Primaria1</h2>
    <table class="table table-striped table-bordered table-hover text-center">
        <thead>
            <tr>
                <th>Grado</th>
                <th>Sección</th>
                <th>Tutor</th>
                <th>Acciones</th> <!-- Nueva columna para acciones -->
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $salones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($salon->nivel === 'primaria'): ?>
            <tr>
                <td class="text-center"><?php echo e($salon->grade); ?></td>
                <td><?php echo e($salon->section); ?></td>
                <td>
                    <?php if($salon->docente): ?>
                        <?php echo e($salon->docente->name); ?> <?php echo e($salon->docente->lastname); ?>

                    <?php else: ?>
                        Sin docente asignado
                    <?php endif; ?>
                </td>
                <td>
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('verAlumnosDelSalon', $salon->id)); ?>" class="btn btn-info btn-sm">Ver Alumnos</a>
                  
                        <a href="<?php echo e(route('borrarSalon', $salon->id)); ?>" class="btn btn-danger btn-sm">Borrar</a>
                    </div>
                </td>
            </tr>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/dashboard/Salones/iteracion1ero.blade.php ENDPATH**/ ?>