<!-- usuarios.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container text-center">
    <h2>Lista de Usuarios registrados </h2>

    <table class="table table-hover">
        <thead>
            <tr class="bg-danger">
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'id'])); ?>" class="text-decoration-none text-white">ID</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'name'])); ?>" class="text-decoration-none text-white">Nombre</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'lastname'])); ?>" class="text-decoration-none text-white">Apellido</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'email'])); ?>" class="text-decoration-none text-white">Email</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'role'])); ?>" class="text-decoration-none text-white">Rol</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'created_at'])); ?>" class="text-decoration-none text-white">Creado en</a></th>
                <th><a href="<?php echo e(route('ordenarusuarios', ['order_by' => 'updated_at'])); ?>" class="text-decoration-none text-white">Ultima conexión</a></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->lastname); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td class="<?php echo e($user->role === 'admi' ? 'bg-danger text-white' : ($user->role === 'user' ? 'bg-info' : '')); ?>"><?php echo e($user->role); ?></td>
                    <td><?php echo e($user->created_at->format('d/m/Y H:i:s')); ?></td>
                    <td><?php echo e($user->updated_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemaAsistencial\resources\views/login/mostrarUsuarios.blade.php ENDPATH**/ ?>